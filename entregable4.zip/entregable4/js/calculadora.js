function calcularIMC(){
    const peso = parseFloat(document.getElementById("peso").value);
    const altura = parseFloat(document.getElementById("altura").value);

    if(peso > 0 && altura >0){
        const alturaMetros = altura/100;
        const imc = peso/(alturaMetros * alturaMetros);
        const estado = calcularEstado(imc);
        document.getElementById("resultado").innerText=`Tu IMC es: ${imc.toFixed(2)}\n Tu Estado es: ${estado}`;
    }else{
        alert("Error, por favor ingrese los valores solicitados");
    }
}

function  calcularEstado(imc){
    if(imc < 15){
        return "Delgadez muy severa";
    }else if(imc < 16){
        return "Delgadez severa";
    }else if(imc < 18.5){
        return "Delgadez";
    }else if(imc < 24.9){
        return "Normal";
    }else if(imc < 29.9){
        return "Sobrepeso";
    }else if(imc < 34.9){
        return "Obesidad moderada";
    }else if(imc < 39.9){
        return "Obesidad severa";
    }else{
        return "Obesidad mórbida";
    }
}