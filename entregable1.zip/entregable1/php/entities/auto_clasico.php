<?php
require_once "../entities/vehiculo.php";
class AutoClasico extends Vehiculo{
    public function __construct(string $marca, string $modelo, string $color, float $precio){
        parent::__construct($marca, $modelo, $color, $precio);
    }
}
?>