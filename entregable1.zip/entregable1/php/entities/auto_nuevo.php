<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
class AutoNuevo extends Vehiculo{
    public function __construct(string $marca, string $modelo, string $color, float $precio, string $marcaRadio, float $potencia){
        parent::__construct($marca, $modelo, $color, $precio, $marcaRadio, $potencia);
    }
}
?>