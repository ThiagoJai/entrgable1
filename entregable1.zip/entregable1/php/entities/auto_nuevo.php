<?php
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";
class AutoNuevo extends Vehiculo{
    public function __construct(string $marca, string $modelo, string $color, float $precio, Radio $radio=null){
        parent::__construct($marca, $modelo, $color, $precio, $radio);
    }

    public function cambiarRadio(Radio $nuevaRadio){
        parent::cambiarRadio($nuevaRadio);
    }

}
?>