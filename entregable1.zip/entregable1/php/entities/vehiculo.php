<?php
require_once "../entities/radio.php";
abstract class Vehiculo{
    private $color;
    private $marca;
    private $modelo;
    private $radio;
    private $precio;

    public function __construct(string $marca, string $modelo, string $color, float $precio){
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->color=$color;
        $this->precio=$precio;
    }

    public function __tostring():string{
        return $this->marca.", ".$this->modelo.", ".$this->color.", ".$this->precio.", ".$this->radio;
    }

    public function agregarRadio(string $marcaRadio, float $potencia){
        $this->radio=new Radio($marcaRadio, $potencia);
        echo"La radio ha sido agregada: ".$this->radio."<br>";
    }

    public function cambiarRadio(string $marcaRadio, float $potencia){
        $this->radio=new Radio($marcaRadio, $potencia);
        echo"La radio ha sido cambiada: ".$this->radio."<br>";
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }

    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>