<?php
require_once "../entities/radio.php";
abstract class Vehiculo{
    private $color;
    private $marca;
    private $modelo;
    private $radio;
    private $precio;

    public function __construct(string $marca, string $modelo, string $color, float $precio, Radio $radio=null){
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->color=$color;
        $this->precio=$precio;
        $this->radio=$radio;
    }

    public function __tostring():string{
        return $this->marca.", ".$this->modelo.", ".$this->color.", ".$this->precio.", ".$this->radio."Sin radio";
    }

    public function agregarRadio(Radio $radio){
        $this->radio=$radio;
        echo"La radio ha sido agregada: ";
    }

    public function cambiarRadio(Radio $nuevaRadio){
        $this->radio=$nuevaRadio;
        echo"La radio ha sido cambiada: ";
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }

    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>