<?php
require_once "../entities/vehiculo.php";
class Radio{
    private $marcaRadio;
    private $potencia;

    public function __construct(string $marcaRadio, float $potencia){
        $this->marcaRadio=$marcaRadio;
        $this->potencia=$potencia;
    }

    public function __tostring():string{
        return $this->marcaRadio.", ".$this->potencia;
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }

    public function __set($property, $value){
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>