<?php ini_set("display_erros", "1"); ?>
<?php
require_once "../entities/auto_nuevo.php";
require_once "../entities/auto_clasico.php";
require_once "../entities/bondi.php";
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";

echo"<h1>Test Vehiculo</h1><br>";

$radio1 = new Radio("Sony", 50);
$radio2 = new Radio("Pioneer", 40);

echo"-- vehiculo1 --<br>";
$vehiculo1 = new AutoNuevo("Toyota", "Corolla", "Blanco", 200000, "Sony", 50);
echo $vehiculo1."<br>";
$vehiculo1->agregarRadio($radio1)."<br>";
echo $radio1."<br>";
echo"-- End Test vehiculo1 --<br><br>";

echo"-- vehiculo2 --<br>";
$vehiculo2 = new AutoClasico("Ford", "Falcon", "Azul", 150000, "Sony", 50);
echo $vehiculo2."<br>";
$vehiculo2->cambiarRadio($radio2)."<br>";
echo $radio2."<br>";
echo"-- End Test vehiculo2 --<br><br>";

echo"-- bondi1 --<br>";
$radio3 = new Radio("Alpine", 25);
$radio4 = new Radio("Kenwood", 30);
$bondi1 = new Bondi("Mercedes Benz", "Daily", "Blanco", 28500000, "Kenwood", 30);
echo $bondi1."<br>";
$bondi1->agregarRadio($radio4)."<br>";
echo $radio4."<br>";
echo"-- End test bondi1 --<br><br>";

echo"-- bondi2 --<br>";
$bondi2 = new Bondi("Mercedez Benz", "Sprinter", "Blanco", 20000000, "Kenwood", 30);
echo $bondi2."<br>";
$bondi2->cambiarRadio($radio3)."<br>";
echo $radio3."<br>";
echo"-- End test bondi2 --";
?>