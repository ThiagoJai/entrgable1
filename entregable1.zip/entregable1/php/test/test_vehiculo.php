<?php ini_set("display_erros", "1"); ?>
<?php
require_once "../entities/auto_nuevo.php";
require_once "../entities/auto_clasico.php";
require_once "../entities/bondi.php";
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";

echo"<h1>Test Vehiculo</h1><br>";

$radio1 = new Radio("Sony", 50);
$radio2 = new Radio("Pioneer", 60);

echo"-- vehiculo1 --<br>";
$vehiculo1 = new AutoNuevo("Toyota", "Corolla", "Blanco", 200000);
echo $vehiculo1."<br>";
$vehiculo1->agregarRadio($radio1)."<br>";
echo $radio1."<br>";
echo"-- End Test vehiculo1 --<br><br>";

echo"-- vehiculo2 --<br>";
$vehiculo2 = new AutoClasico("Ford", "Falcon", "Azul", 150000);
echo $vehiculo2."<br>";
$vehiculo2->agregarRadio($radio1)."<br>";
echo $radio1."<br>";
$vehiculo2->cambiarRadio($radio2)."<br>";
echo $radio2."<br>";
echo"-- End Test vehiculo2 --<br><br>";

echo"-- bondi1 --<br>";
$bondi1 = new Bondi("Mercedes Benz", "1418 Italbus", "Blanco", 28500000);
echo $bondi1."<br>";
$bondi1->agregarRadio($radio1)."<br>";
echo $radio1."<br>";
$bondi1->cambiarRadio($radio2)."<br>";
echo $radio2."<br>";
?>