<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../entities/auto_nuevo.php";
require_once "../entities/auto_clasico.php";
require_once "../entities/bondi.php";
require_once "../entities/vehiculo.php";
require_once "../entities/radio.php";

echo"<h1>Test Vehiculo</h1><br>";

echo"-- Auto Nuevo --<br>";
$vehiculo1 = new AutoNuevo("Toyota", "Corolla", "Rojo", 200000, "Sony", 35);
echo $vehiculo1."<br>";
$vehiculo1->cambiarRadio("Phillips", 45);
echo"-- End Test Auto Nuevo --<br><br>";

echo"-- Auto Clasico --<br>";
$vehiculo2 = new AutoClasico("Ford", "Falcon", "Azul", 150000);
echo $vehiculo2."<br>";
echo $vehiculo2->agregarRadio("Pioneer", 45);
echo $vehiculo2->cambiarRadio("Pionner", 48);
echo"-- End Test Auto Clasico --<br><br>";

echo"-- Bondi --<br>";
$bondi1 = new Bondi("Mercedes Benz", "Daily", "Blanco", 28500000);
echo $bondi1."<br>";
$bondi1->agregarRadio("Alpine", 25)."<br>";
$bondi1->cambiarRadio("Alpine", 24)."<br>";
echo"-- End test bondi1 --<br><br>";

echo"-- Bondi --<br>";
$bondi2 = new Bondi("Mercedez Benz", "Sprinter", "Blanco", 20000000);
echo $bondi2."<br>";
$bondi2->agregarRadio("JVC", 45)."<br>";
$bondi2->cambiarRadio("JVC", 19)."<br>";
echo"-- End test bondi2 --";
?>