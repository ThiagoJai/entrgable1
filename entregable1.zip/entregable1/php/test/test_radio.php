<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../entities/radio.php";

echo"<h1>Test Radio</h1><br>";
echo"-- Radio1 --<br>";
$radio1= new Radio("Sony", 20);
echo $radio1."<br>";
echo"-- End Radio1 --<br><br>";

echo"-- Radio2 --<br>";
$radio2 = new Radio("JVC", 35);
echo $radio2."<br>";
echo"-- End Radio2 --<br>";
?>