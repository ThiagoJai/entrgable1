<?php ini_set("display_errors","1");?>
<?php 
    //http://localhost/objetos/clase13/php/test/test_exceptions.php
    //http://localhost/objetos/clase12/php/test/test_php.php
    echo "Versión PHP: ".phpversion()."<br>";
    echo phpinfo().'<br>';
?>