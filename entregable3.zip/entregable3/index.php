<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cálculadora del IMC</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <div class="container mt-5">
        <h1 class="text-center">Calculadora de IMC</h1>
        <form method="post" class="mt-4">
            <div class="mb-3">
                <label for="peso" class="etiqueta">Peso (kg):</label>
                <input type="number" class="form-control" id="peso" name="peso" required>
            </div>
            <div class="mb-3">
                <label for="altura" class="etiqueta">Altura (cm):</label>
                <input type="number" class="form-control" id="altura" name="altura" required>
            </div>
                <div class="mb-3 row">
                <label class="etiqueta">Resultado: </label>
                <div class="col-sm-9 form-control">
                     <?php include_once "php/index.php"; 
                    if ($_SERVER["REQUEST_METHOD"] == "POST"){
                      $peso = $_POST['peso'];
                      $altura = $_POST['altura'];
                      $imc=calcularIMC($peso, $altura);
                      $estado=calcularEstado($imc);
                      echo"Tu IMC es: ".$imc."<br>"." Y tu estado es: ".$estado;
                    }else{
                      echo"Error, por favor ingrese los valores solicitados";
                    }
                ?> 
                </div>
                 
            
                
            <button type="submit" class="boton botonCalcular" value="Calcular">Calcular</button>
            <button type="reset" class="boton botonBorrar" value="Borrar">Borrar</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
</body>
</html>
