<?php
$peso = $_POST ['peso'];
$altura = $_POST ['altura'];
     function calcularIMC(int $peso, int $altura):float{
        $alturaMetros = $altura/100;
        return $peso/($alturaMetros*$alturaMetros);
    }

      function  calcularEstado(float $imc):string{
        if($imc < 15){
            return "Delgadez muy severa";
        }elseif($imc < 16){
            return "Delgadez severa";
        }elseif($imc < 18.5){
            return "Delgadez";
        }elseif($imc < 24.9){
            return "Normal";
        }elseif($imc > 29.9){
            return "Sobrepeso";
        }elseif($imc > 34.9){
            return "Obesidad moderada";
        }elseif($imc > 39.9){
            return "Obesidad severa";
        }else{
            return "Obesidad mórbida";
        }
    }

    if ($_SERVER["REQUEST_METHOD"] == "POST"){
        $peso = $_POST['peso'];
        $altura = $_POST['altura'];
        $imc=calcularIMC($peso, $altura);
        $estado=calcularEstado($imc);
        echo"Tu IMC es: ".$imc."<br>"." Y tu estado es: ".$estado;
      }else{
        echo"Error, por favor ingrese los valores solicitados";
      }
?>