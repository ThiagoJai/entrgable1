<?php

require_once "../entities/vehiculo.php";
require_once "../interfaces/i_concesionaria.php";

class Concesionaria implements I_Concesionaria{
    private array $vehiculos=[];

    public function __construct(){
        $this->vehiculos=$this->cargarVehiculos();
    }

    public function cargarVehiculos():array{
        return[
            new Auto("Peugeot", "206", 20000000, 4),
            new Moto("Honda", "Titan", 6000000, 125),
            new Auto("Peugeot", "208", 25000000, 5),
            new Moto("Yamaha", "YBR", 8050050, 160)
        ];
    }

    public function mostrarVehiculos(){
        foreach($this->vehiculos as $vehiculo){
            echo $vehiculo;
            echo"<br>\n";
        }
    }

    public function vehiculoMasCaro():void{
        $masCaro = $this->vehiculos[0];
        foreach($this->vehiculos as $vehiculo){
            if($vehiculo->getPrecio() > $masCaro->getPrecio()){
                $masCaro = $vehiculo;
            }
        }
        echo"Vehiculo mas caro es: ".$masCaro->getMarca()." ".$masCaro->getModelo();
        echo"<br>\n";
    }

    public function vehiculoMasBarato():void{
        $masBarato = $this->vehiculos[0];
        foreach($this->vehiculos as $vehiculo){
            if($vehiculo->getPrecio() < $masBarato->getPrecio()){
                $masBarato = $vehiculo;
            }
        }
        echo "Vehiculo mas barato es: ".$masBarato->getMarca()." ".$masBarato->getModelo();
        echo"<br>\n";
    }

    public function vehiculoConLetraY():void{
        foreach($this->vehiculos as $vehiculo){
            if(strpos($vehiculo->getModelo(), 'Y') !== false){
                echo"Vehiculo que contiene en el modelo la letra Y: ". $vehiculo->getMarca() . " " . $vehiculo->getModelo() . " $" . number_format($vehiculo->getPrecio(), 2, ',', '.');
                echo"<br>\n";
            }
        }
    }

    public function vehiculosOrdenadosPorPrecio():void{
        usort($this->vehiculos, function($a, $b){
            return $b->getPrecio() <=> $a->getPrecio();
        });
        echo"Vehiculos ordenados por precio de mayor a menor: "."<br>";
        foreach($this->vehiculos as $vehiculo){
            echo $vehiculo->getMarca()." ".$vehiculo->getModelo();
            echo"<br>\n";
        }
    }

    public function vehiculosOredenadosPorOrdenNatural(){
        usort($this->vehiculos, function($a, $b){
            return[$a->getMarca(), $a->getModelo()] <=> [$b->getMarca(), $b->getModelo()];
        });
        echo"Vehículos ordenados por orden natural (marca, modelo, precio): "."<br>";
        foreach($this->vehiculos as $vehiculo){
            echo $vehiculo;
            echo"<br>\n";
        }
    }
  }      
?>