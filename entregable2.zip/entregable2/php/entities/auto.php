<?php
require_once "../entities/vehiculo.php";

class Auto extends Vehiculo{
    private $puertas;

    public function __construct(string $marca, string $modelo, float $precio, int $puertas){
        parent::__construct($marca, $modelo, $precio);
        $this->puertas=$puertas;
    }

    public function __tostring():string{
        return parent::__tostring().", Puertas: ".$this->puertas;
    }
}
?>