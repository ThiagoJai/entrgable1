<?php
require_once "../entities/concesionaria.php";
abstract class Vehiculo{
    private $marca;
    private $modelo;
    private $precio;

    public function __construct(string $marca, string $modelo, float $precio){
        $this->marca=$marca;
        $this->modelo=$modelo;
        $this->precio=$precio;
    }

    public function __tostring():string{
        return "Marca: ".$this->marca.", Modelo: ".$this->modelo.", Precio: ".$this->precio;
    }

    public function getPrecio():float{
        return $this->precio;
    }

    public function getMarca(): string {
        return $this->marca;
    }

    public function getModelo(): string {
        return $this->modelo;
    }

    public function __get($property){
        if(property_exists($this,$property)){
            return $this->$property;
        }
    }

    public function __set($property, $value){
        //insert into control_auditoria (user, ip, fecha, hora, accion) values (?,?,?,?,?);
        if(property_exists($this,$property)){
            $this->$property = $value;
        }
    }
}
?>