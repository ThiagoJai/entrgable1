<?php
interface I_Concesionaria{
    function cargarVehiculos():array;
    function mostrarVehiculos();
    function vehiculoMasCaro():void;
    function vehiculoMasBarato():void;
    function vehiculoConLetraY():void;
    function vehiculosOrdenadosPorPrecio():void;
    function vehiculosOredenadosPorOrdenNatural();
}
?>