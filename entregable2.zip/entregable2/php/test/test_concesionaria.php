<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../entities/concesionaria.php";
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";

echo"<h1>Test Concesionaria</h1><br>";
$concesionaria = new Concesionaria();
$concesionaria->cargarVehiculos();
$concesionaria->mostrarVehiculos(); 

echo"===========================================<br><br>";

$concesionaria->vehiculoMasCaro();
$concesionaria->vehiculoMasBarato();
$concesionaria->vehiculoConLetraY();

echo"==========================================<br><br>";

$concesionaria->vehiculosOrdenadosPorPrecio();

echo"==========================================<br><br>";

$concesionaria->vehiculosOredenadosPorOrdenNatural();
?>