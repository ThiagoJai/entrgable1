<?php ini_set("display_errors", "1"); ?>
<?php
require_once "../entities/vehiculo.php";
require_once "../entities/auto.php";
require_once "../entities/moto.php";

echo"<h1>Test Vehiculo</h1><br>";
$vehiculo = new Auto("Peugeot", "206", 200000, 4);
echo $vehiculo."<br>";
$vehiculo = new Moto("Honda", "Titan", 60000, 125);
echo $vehiculo."<br>";
$vehiculo = new Auto("Peugeot", "208", 250000, 5);
echo $vehiculo."<br>";
$vehiculo = new Moto("Yamaha", "YBR", 80500,160);
echo $vehiculo."<br>";
?>