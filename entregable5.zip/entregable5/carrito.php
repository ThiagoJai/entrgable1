<!-- <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css">
<div class="cart" id="cart">
        <h4 class="cart-title">Tu Carrito</h4>
        <div class="cart-content"></div>
        <div class="total">
            <span>Total: </span>
            <span class="total-price">$0</span>
        </div>
        <button type="submit" class="btn btn-success btn-block mt-3">Comprar Ahora</button>
        <button type="reset" class="btn btn-danger btn-block mt-2" id="cart-close" onclick="vaciarCarrito()">Vaciar Carrito</button>
    </div> -->