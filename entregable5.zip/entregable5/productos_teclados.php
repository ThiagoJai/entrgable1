<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ComputacionYa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include_once "menu.php"; ?>
    <div container-lg>
        <h1>Productos Destacados</h1>
        <div class="row g-4">
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag16.jpeg" class="card-img-top" alt="Producto 1">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Bluethooth Logitech Pebble Key 2 K380s Rosa Español</h5>
                        <p class="card-text">$47.169</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag17.jpeg" class="card-img-top" alt="Producto 2">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Genius Kb-116 QWERTY Español Color Negro</h5>
                        <p class="card-text">$9.603</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag18.jpeg" class="card-img-top" alt="Producto 3">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Multimedia Pc Computadora USB trabajo Oficina Casa</h5>
                        <p class="card-text">$10.321</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag19.jpeg" class="card-img-top" alt="Producto 4">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Gamer USB Retroiluminado Xemoki XK-G7V2</h5>
                        <p class="card-text">$8.208</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag20.jpeg" class="card-img-top" alt="Producto 5">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Bluethooth Logitech K380 Color Sand Español Circuit Color Beige</h>
                        <p class="card-text">$1200</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag21.jpeg" class="card-img-top" alt="Producto 6">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Plegable de Silicon</h5>
                        <p class="card-text">$15.560</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag22.jpeg" class="card-img-top" alt="Producto 7">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Usb Global K227 Multimedia Pc Notebook All In One</h5>
                        <p class="card-text">$5.300</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag23.jpeg" class="card-img-top" alt="Producto 8">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Numerico Genius 1000 Inalambrico Keypad Pc Notebook</h5>
                        <p class="card-text">$12.610</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card">
                    <img src="imags/imag24.jpeg" class="card-img-top" alt="Producto 9">
                    <div class="card-body" style="width: 18rem;">
                        <h5 class="card-title">Teclado Plegable con Bluethooth</h5>
                        <p class="card-text">$60.000</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag25.jpeg" class="card-img-top" alt="Producto 10">
                    <div class="card-body">
                        <h5 class="card-title">Teclado Bluethooth Logitech Pabble Keys 2 K380s Grafico Idioma Español</h5>
                        <p class="card-text">$45.599</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html>