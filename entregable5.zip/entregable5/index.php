<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ComputacionYa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet"> 
</head>
<body>
    <?php include_once "menu.php"; ?>
    <h1>La Pc que vos queres está acá</h1>
    <div id="carouselExample" class="carousel slide corousel-fade" data-bs-slide="carousel">
        <div class="carousel-inner">
          <div class="carousel-item active">
            <img src="imags/imag6.jpeg" class="d-block w-100 carousel-image" alt="Promo 1">
          </div>
          <div class="carousel-item">
            <img src="imags/imag7.jpeg" class="d-block w-100 carousel-image" alt="Promo 2">
          </div>
          <div class="carousel-item">
            <img src="imags/imag8.jpeg" class="d-block w-100 carousel-image" alt="Promo 3">
          </div>
        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExample" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExample" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
    <div container-lg>
        <h1>Productos Destacados</h1>
        <div class="row g-4">
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag1.jpeg" class="card-img-top" alt="Producto 1">
                    <div class="card-body">
                        <h5 class="card-title">Notebook HP Intel I3 11a Generacion</h5>
                        <p class="card-text">$940.000</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag2.jpeg" class="card-img-top" alt="Producto 2">
                    <div class="card-body">
                        <h5 class="card-title">Monitor LG 20MK400H led 19.5" negro 100V/240V</h5>
                        <p class="card-text">$143.999</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag3.jpeg" class="card-img-top" alt="Producto 3">
                    <div class="card-body">
                        <h5 class="card-title">Pc Armada Gamer Amd Ryzen 5 4600g Ssd 480gb 16gd Dddr4 Prem</h5>
                        <p class="card-text">$496.999</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag4.jpeg" class="card-img-top" alt="Producto 4">
                    <div class="card-body">
                        <h5 class="card-title">Placa Video Sentey Radeon Rx 560 4gb Ddr5 Hdmi</h5>
                        <p class="card-text">$129.699</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag10.jpeg" class="card-img-top" alt="Producto 5">
                    <div class="card-body">
                        <h5 class="card-title">Impresora simple función monocromática Pantum Hero P2509W con wifi 220V</h5>
                        <p class="card-text">$139.999</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag11.jpeg" class="card-img-top" alt="Producto 6">
                    <div class="card-body">
                        <h5 class="card-title">Watch Onn FHD Streaming Stick 2da Generación Google Tv 8gb 1.5 Gb Ram Color Negro Control Remoto de Voz</h5>
                        <p class="card-text">$48.870</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag12.jpeg" class="card-img-top" alt="Producto 7">
                    <div class="card-body">
                        <h5 class="card-title">Motherboard Asus Prime B460m-a R2.0 Intel Socket 1200 Intel Color Negro</h5>
                        <p class="card-text">$151.357</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag13.jpeg" class="card-img-top" alt="Producto 8">
                    <div class="card-body">
                        <h5 class="card-title">Joystick inalámbrico Redragon Harrow G808 negro</h5>
                        <p class="card-text">$43.499</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag14.jpeg" class="card-img-top" alt="Producto 9">
                    <div class="card-body">
                        <h5 class="card-title">Parlantes Genius Sp Q160 Pc Notebook Usb 3.5mm Parlante Color Rojo</h5>
                        <p class="card-text">$19.560</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem">
                    <img src="imags/imag15.jpeg" class="card-img-top" alt="Producto 10">
                    <div class="card-body">
                        <h5 class="card-title">Mouse Oficina Genius Dx 101 Optico Usb Con Cable Color Negro</h5>
                        <p class="card-text">$4.898</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html>