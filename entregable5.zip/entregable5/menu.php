<nav class="navbar navbar-expand-lg bg-body-tertiary" style="background-color: #;">
  <div class="container-fluid">
    <a class="navbar-brand" href="#">ComputacionYa</a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarScroll" aria-controls="navbarScroll" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarScroll">
      <ul class="navbar-nav me-auto my-2 my-lg-0 navbar-nav-scroll" style="--bs-scroll-height: 100px;">
        <li class="nav-item">
          <a class="nav-link active" aria-current="page" href="index.php">Inicio</a>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Productos
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="productos_PC.php">PC</a></li>
            <li><a class="dropdown-item" href="productos_almacenamiento.php">Almacenamiento</a></li>
            <li><a class="dropdown-item" href="productos_teclados.php">Teclados</a></li>
          </ul>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle"  href="#" role="button" data-bs-toggle="dropdown" aria-expanded="false">
            Configuracion
          </a>
          <ul class="dropdown-menu">
            <li><a class="dropdown-item" href="productos.php">Productos</a></li>
            <li><a class="dropdown-item" href="usuarios.php">Usuarios</a></li>
            <li><a class="dropdown-item" href="carritos.php">Carritos</a></li>
          </ul>
        </li>
      </ul>
        </li>
      </ul>
      <form class="d-flex me-3" role="search">
        <input class="form-control me-2" name="buscar" value="" type="search" placeholder="Search" aria-label="Search">
        <button class="btn btn-outline-success" type="submit">Search</button>
      </form>
      <a href="#" class="btn btn-outline-primary position-relative">
        <i class="bi bi-cart-fill"></i>
        <span id="cart-count" class="position-absolute top-0 start-100 translate-middle badge rounded-pill bg-danger">0</span>
      </a>
    </div>
  </div>
</nav>
