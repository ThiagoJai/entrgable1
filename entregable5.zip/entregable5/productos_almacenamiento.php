<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ComputacionYa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include_once "menu.php"; ?>
    <div container-lg>
        <h1>Productos Destacados</h1>
        <div class="row g-4">
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag34.jpeg" class="card-img-top" alt="Producto 1">
                    <div class="card-body">
                        <h5 class="card-title">Unida Sólida Interna Kingston SA400s37/960g 960gb</h5>
                        <p class="card-text">$68.890</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag35.jpeg" class="card-img-top" alt="Producto 2">
                    <div class="card-body">
                        <h5 class="card-title">Disco Duro Interno Seagate SkyHawk Sur</h5>
                        <p class="card-text">$9.603</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card">
                    <img src="imags/imag36.jpeg" class="card-img-top" alt="Producto 3">
                    <div class="card-body">
                        <h5 class="card-title">Disco Sólido Interno Kingston SKC600/512g 2.5 512gb Negro</h>
                        <p class="card-text">$92.063</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag37.jpeg" class="card-img-top" alt="Producto 4">
                    <div class="card-body">
                        <h5 class="card-title">Disco Duro Externo Seagate 1tb Hard Drive USB 3.0</h5>
                        <p class="card-text">$89.528</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag38.jpeg" class="card-img-top" alt="Producto 5">
                    <div class="card-body">
                        <h5 class="card-title">Disco Solido Kingston Ssd 1tb Nvme Pcie 4.0 M.2 Snv2s/1000g Color Azul</h5>
                        <p class="card-text">$75.189</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag39.jpeg" class="card-img-top" alt="Producto 6">
                    <div class="card-body">
                        <h5 class="card-title">Disco Sólido M2 Lexar Nm620 256gb M.2 Negro</h5>
                        <p class="card-text">$30.998</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag40.jpeg" class="card-img-top" alt="Producto 7">
                    <div class="card-body">
                        <h5 class="card-title">Kingston DataTraveler Exodia DTX/128 128 GB negro</h5>
                        <p class="card-text">13.890</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag41.jpeg" class="card-img-top" alt="Producto 8">
                    <div class="card-body">
                        <h5 class="card-title">Tarjeta de memoria Kingston SDCS2SP Canvas Select Plus con adaptador SD 128GB</h5>
                        <p class="card-text">$12.667</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag42.jpeg" class="card-img-top" alt="Producto 9">
                    <div class="card-body">
                        <h5 class="card-title">Tarjeta de memoria Kingston SDCS2/64GB Canvas Select Plus con adaptador SD 64GB</h5>
                        <p class="card-text">$7.399</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag43.jpeg" class="card-img-top" alt="Producto 10">
                    <div class="card-body">
                        <h5 class="card-title">Pendrive SanDisk Cruzer Blade SDCZ50-016G-B35 16GB 2.0 negro y rojo</h5>
                        <p class="card-text">$7.750</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html>