document.getElementById('cart-icon').addEventListener('click', function(event) {
    event.preventDefault();
    toggleCart(); 
});

const carrito=[];
const total=0;

function agregarAlCarrito(nombre, precio){
    carrito.push({nombre, precio});
    total += precio;
    actualizarCarrito();
}

function actualizarCarrito(){
    const cartContent = document.querySelector('.cart-content');
    const cartCount = document.getElementById('cart-count');
    const totalPrice = document.querySelector('total-price');
    
    cartContent.innerHTML = '';
    carrito.forEach((producto, index)=>{
        cartContent.innerHTML += `<p>${producto.nombre} - 
        $${producto. precio. toLocaleString()}<button onclick="eliminarDelCarrito(${index})">Eliminar</button></p>`;
    });

    cartCount.innerText = carrito.length;
    totalPrice.innerText = total.toLocaleString();
}

function toggleCart(){
    const cart = document.getElementById('cart');
    cart.style.display = (cart.style.display === 'none' || cart.style.display === '')? 'block' : 'none';
}

function vaciarCarrito(){
    carrito = [];
    total = 0;
    actualizarCarrito();
    document.getElementById('cart').style.display = 'none';
}

function eliminarDelCarrito(index){
    carrito.splice(index, 1);
    total -= carrito[index].precio;
    actualizarCarrito
}