<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ComputacionYa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet"> 
</head>
<body>
   <?php include_once "menu.php"; ?>
   <div container-lg>
    <h1 class="text-center p-2">Mantenimiento de Carritos</h1>
    <form class="p-4 bg-info-subtle">
      <div class="mb-3 row">
        <label for="usuario_id" class="col-sm-3 col-form-label text-primary">Usuario_id: </label>
        <div class="col-sm-9">
            <input type="number" class="form-control text-primary" id="usuario_id" name="usuario_id" value="">
        </div>
      </div>
      <div class="mb-3 row">
        <label for="producto_id" class="col-sm-3 col-form-label text-primary">Producto_id: </label>
        <div class="col-sm-9">
            <input type="number" class="form-control text-primary" id="producto_id" name="producto_id" value="">
        </div>
      </div>
      <div class="mb-3 row">
        <label for="cantidad" class="col-sm-3 col-form-label text-primary">Cantidad: </label>
        <div class="col-sm-9">
            <input type="number" class="form-control text-primary" id="cantidad" name="cantidad" value="">
        </div>
      </div>
      <div class="mb-3 row">
        <button type="submit" class="btn btn-success col-sm-3 m-2">Guardar</button>
        <button type="reset" class="btn btn-danger col-sm-3 m-2">Borrar</button>
      </div>
      <div class="mb-3 row">
        <label for="info" class="col-sm-3 col-form-label text-primary">Informacion: </label>
        <div class="col-sm-9">
          <div class="form-control text-primary" id="info">
              <?php include_once "php/fonts/carritosInsert.php"; ?>
          </div>
        </div>
      </div>
    </form>
    <table class="table table-success table-hover table-striped">
        <thead>
          <tr>
            <th scope="col">Id</th>
            <th scope="col">Usuario_id</th>
            <th scope="col">Producto_id</th>       
            <th scope="col">Cantidad</th>
            <th scope="col">Borrar</th>
          </tr>
        </thead>
        <tbody>
          <?php
            include_once "php/fonts/carritosTable.php";
           ?>
        </tbody>
    </table>
  </div>
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
  <script src="js/main.js"></script>
</body>
</html>