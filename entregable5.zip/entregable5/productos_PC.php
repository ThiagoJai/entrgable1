<!DOCTYPE html>
<html lang="es">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ComputacionYa</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-QWTKZyjpPEjISv5WaRU9OFeRpok6YctnYmDr5pNlyT2bRjXh0JMhjY6hW+ALEwIH" crossorigin="anonymous">
    <link rel="stylesheet" href="css/style.css">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons/font/bootstrap-icons.css" rel="stylesheet">
</head>
<body>
    <?php include_once "menu.php"; ?>
    <div container-lg>
        <h1>Productos Destacados</h1>
        <div class="row g-4">
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag3.jpeg" class="card-img-top" alt="Producto 1">
                    <div class="card-body">
                        <h5 class="card-title">Pc Armada Gamer Amd Ryzen 5 4600g Ssd 480gb 16gd Dddr4 Prem</h5>
                        <p class="card-text">$496.999</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag9.jpeg" class="card-img-top" alt="Producto 2">
                    <div class="card-body">
                        <h5 class="card-title">Pc Armada Gamer Amd Ryzen 5 4600g Ram 16gb Radeon Vega Hdmi</h5>
                        <p class="card-text">$439.999</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag26.jpeg" class="card-img-top" alt="Producto 3">
                    <div class="card-body">
                        <h5 class="card-title">Computadora Cpu Armada
                             Intel Core I3 8gb 120gb Ssd
                             (Reacondicionado)</h5>
                        <p class="card-text">$224.990</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag27.jpeg" class="card-img-top" alt="Producto 4">
                    <div class="card-body">
                        <h5 class="card-title">Computadora Pc Cpu 
                            Solarmax Intel Core 
                            I5 11va 16gb 480Ssd</h5>
                        <p class="card-text">$678.498</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag28.jpeg" class="card-img-top" alt="Producto 5">
                    <div class="card-body">
                        <h5 class="card-title">Pc Cpu Computadora 
                            Intel Core I7 16gb 
                            Ram 480 Ssd Hdmi</h5>
                        <p class="card-text">$349.998</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                    </div>
                </div>
            </div>
            <div class="col-md-4 product-card">
                <div class="card" style="width: 18rem;">
                    <img src="imags/imag29.jpeg" class="card-img-top" alt="Producto 6">
                    <div class="card-body">
                        <h5 class="card-title">Pc Armada Gamer Amd Ryzen
                             5 4600g 16g Ssd
                             480gb-Mx516 1</h5>
                        <p class="card-text">$333.727</p>
                        <button class="btn btn-success m-2" onclick="agregarAlCarrito()">Agregar al Carrito</button>
                        <button class="btn btn-primary m-2">Comprar ahora</button>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-YvpcrYf0tY3lHB60NNkmXc5s9fDVZLESaAA55NDzOxhy9GkcIdslK1eN7N6jIeHz" crossorigin="anonymous"></script>
    <script src="js/script.js"></script>
</body>
</html>