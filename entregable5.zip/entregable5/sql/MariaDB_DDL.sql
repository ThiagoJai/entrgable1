-- Active: 1713999222316@@127.0.0.1@3306
drop database if exists tienda_v;
create database tienda_v;
use tienda_v;

create table usuarios(
    id integer AUTO_INCREMENT,
    nombre varchar(25) not null,
    correo varchar(25) not null,
    contraseña varchar(50) not null,
    primary key(id)
);

create table categorias(
    id integer AUTO_INCREMENT,
    nombre varchar(25) not null,
    descripcion text,
    primary key(id)
);

create table productos(
    id integer AUTO_INCREMENT,
    categoria_id int null references categorias(id),
    nombre varchar(25) not null,
    precio varchar(100) not null,
    stock int,
    foreign key(categoria_id) references categorias(id),
    primary key (id)
);

create table carrito(
    id integer AUTO_INCREMENT,
    usuario_id int null,
    producto_id int null,
    cantidad int not null,
    foreign key(usuario_id) references usuarios(id) on delete cascade,
    foreign key(producto_id) references productos(id),
    primary key(id)
);

create table metodos_pago(
    id integer AUTO_INCREMENT,
    usuario_id int not null references usuario(id),
    numero_tarjeta varchar(20) not null,
    fecha_expiracion date not null,
    cvv varchar(5) not null,
    foreign key(usuario_id) references usuarios(id) on delete cascade,
    primary key(id)
);

create table pagos(
    id integer AUTO_INCREMENT,
    orden_id int not null ,
    metodos_pago_id int not null,
    monto int not null,
    fecha_pago datetime,
    foreign key(metodos_pago_id) references metodos_pago(id),
    primary key(id)
);

create table decuentos(
    id integer AUTO_INCREMENT,
    producto_id int references productos(id),
    fecha_inicio date not null,
    foreign key(producto_id) references productos(id),
    primary key(id)
);

create table historial_precios(
    id integer AUTO_INCREMENT,
    producto_id int not null references productos(id),
    precio_anterior boolean not null,
    precio_nuevo boolean not null,
    fecha_cambio timestamp,
    foreign key(producto_id) references productos(id) on delete cascade,
    primary key(id)
);