-- Active: 1730468170612@@127.0.0.1@3306@tienda_v
drop database if exists tienda_v;
create database tienda_v;
use tienda_v;


create table usuarios(
    id integer AUTO_INCREMENT,
    nombre varchar(25) not null,
    correo varchar(50) not null,
    password varchar(50) null,
    primary key(id)
);

create table categorias(
    id integer AUTO_INCREMENT,
    nombre varchar(50) not null,
    descripcion text,
    primary key(id)
);

create table productos(
    id integer AUTO_INCREMENT,
    categoria_id int not null,
    nombre varchar(25) not null,
    precio varchar(100) not null,
    stock int,
    foreign key(categoria_id) references categorias(id),
    primary key (id)
);

create table carritos(
    id integer AUTO_INCREMENT,
    usuario_id int not null,
    producto_id int not null,
    cantidad int not null,
    foreign key(usuario_id) references usuarios(id) on delete cascade,
    foreign key(producto_id) references productos(id),
    primary key(id)
);