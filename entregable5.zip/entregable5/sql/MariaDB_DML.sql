-- Active: 1731507198059@@127.0.0.1@3306@tienda_v
use tienda_v;
insert into usuarios(nombre, correo, password)VALUES
('Juan Pérez', 'juan.perez20@example.com', 'xxxxxx'),
('Ana Gómez', 'ana.gomez20@example.com', 'xxxxxx'),
('Carlos Díaz', 'carlos.diaz20@example.com', 'xxxxxxx'),
('María Fernández', 'maria.fernandez20@example.com', 'xxxxxx'),
('Pedro Martínez', 'pedro.martinez20@example.com', 'xxxxxx'),
('Lucía Reyes', 'lucia.reyes20@example.com', 'xxxxxx'),
('Tomás Rojas', 'tomas.rojas20@example.com', 'xxxxx'),
('Elena García', 'elena.garcia20@example.com', 'xxxxxx'),
('David Romero', 'david.romero20@example.com', 'xxxxxxx'),
('Julia Vargas', 'julia.vargas20@example.com', 'xxxxxx'),
('Sofía Méndez', 'sofia.mendez20@example.com', 'xxxxxxx'),
('Gabriel Ruiz', 'gabriel.ruiz20@example.com', 'xxxxx'),
('Raúl Silva', 'raul.silva20@example.com', 'xxxxxx'),
('Isabel Ríos', 'isabel.rios20@example.com', 'xxxxxx'),
('Pablo Torres', 'pablo.torres20@example.com', 'xxxxx'),
('Victoria Castro', 'victoria.castro20@example.com', 'xxxxxx'),
('Andrés Pérez', 'andres.perez20@example.com', 'xxxxx'),
('Marta López', 'marta.lopez20@example.com', 'xxxxx');

insert into categorias(nombre, descripcion)values 
('Laptops', 'Computadoras portátiles de diversas marcas y modelos'),
('Accesorios', 'Accesorios informáticos como teclados, ratones y cámaras web'),
('Almacenamiento', 'Dispositivos de almacenamiento como discos duros y SSDs'),
('Componentes', 'Componentes internos como tarjetas gráficas y procesadores'),
('Monitores', 'Pantallas y monitores de diversas marcas y modelos'),
('Redes', 'Dispositivos de redes como routers y switches'),
('Periféricos', 'Periféricos adicionales como impresoras y escáneres'),
('Software', 'Software y licencias para diversos sistemas operativos'),
('Memorias', 'Memorias RAM y tarjetas de memoria para dispositivos');

insert into productos(categoria_id, nombre, precio, stock)values 
(1, 'Laptop Dell Inspiron', '1200', 22),
(1, 'Laptop HP Envy', '1150', 20),
(1, 'Laptop Lenovo ThinkPad', '1300', 18),
(2, 'Teclado mecánico', '85', 30),
(2, 'Ratón óptico inalámbrico', '25', 50),
(3, 'Disco duro externo 1TB', '60', 45),
(3, 'SSD Kingston 512GB', '75', 25),
(4, 'Tarjeta gráfica NVIDIA GTX 1660', '280', 15),
(4, 'Procesador Intel i5', '200', 18),
(5, 'Impresora multifuncional', '120', 20),
(5, 'Escáner portátil', '80', 22);

insert into carritos(usuario_id, producto_id, cantidad)values 
(2, 1, 2),
(3, 3, 1),
(4, 5, 3),
(5, 6, 1),
(6, 7, 1),
(1, 8, 2),
(1, 1, 1),
(2, 4, 2),
(3, 7, 1),
(4, 9, 2),
(5, 10, 1),
(6, 11, 1);