-- Active: 1713999222316@@127.0.0.1@3306@tienda_v
use tienda_v;
insert into usuarios(nombre, correo)VALUES
('Juan Pérez', 'juan.perez20@example.com'),
('Ana Gómez', 'ana.gomez20@example.com'),
('Carlos Díaz', 'carlos.diaz20@example.com'),
('María Fernández', 'maria.fernandez20@example.com'),
('Pedro Martínez', 'pedro.martinez20@example.com'),
('Lucía Reyes', 'lucia.reyes20@example.com'),
('Tomás Rojas', 'tomas.rojas20@example.com'),
('Elena García', 'elena.garcia20@example.com'),
('David Romero', 'david.romero20@example.com'),
('Julia Vargas', 'julia.vargas20@example.com'),
('Sofía Méndez', 'sofia.mendez20@example.com'),
('Gabriel Ruiz', 'gabriel.ruiz20@example.com'),
('Raúl Silva', 'raul.silva20@example.com'),
('Isabel Ríos', 'isabel.rios20@example.com'),
('Pablo Torres', 'pablo.torres20@example.com'),
('Victoria Castro', 'victoria.castro20@example.com'),
('Andrés Pérez', 'andres.perez20@example.com'),
('Marta López', 'marta.lopez20@example.com');

insert into categorias(nombre, descripcion)values 
('Laptops', 'Computadoras portátiles de diversas marcas y modelos'),
('Accesorios', 'Accesorios informáticos como teclados, ratones y cámaras web'),
('Almacenamiento', 'Dispositivos de almacenamiento como discos duros y SSDs'),
('Componentes', 'Componentes internos como tarjetas gráficas y procesadores'),
('Monitores', 'Pantallas y monitores de diversas marcas y modelos'),
('Redes', 'Dispositivos de redes como routers y switches'),
('Periféricos', 'Periféricos adicionales como impresoras y escáneres'),
('Software', 'Software y licencias para diversos sistemas operativos'),
('Memorias', 'Memorias RAM y tarjetas de memoria para dispositivos');

insert into productos(categoria_id, nombre, precio, stock)values 
(1, 'Laptop Dell Inspiron', '1200', 22),
(1, 'Laptop HP Envy', '1150', 20),
(1, 'Laptop Lenovo ThinkPad', '1300', 18),
(2, 'Teclado mecánico', '85', 30),
(2, 'Ratón óptico inalámbrico', '25', 50),
(3, 'Disco duro externo 1TB', '60', 45),
(3, 'SSD Kingston 512GB', '75', 25),
(4, 'Tarjeta gráfica NVIDIA GTX 1660', '280', 15),
(4, 'Procesador Intel i5', '200', 18),
(5, 'Impresora multifuncional', '120', 20),
(5, 'Escáner portátil', '80', 22);

insert into carritos(usuario_id, producto_id, cantidad)values 
(2, 1, 2),
(3, 3, 1),
(4, 5, 3),
(5, 6, 1),
(6, 7, 1),
(1, 8, 2),
(1, 1, 1),
(2, 4, 2),
(3, 7, 1),
(4, 9, 2),
(5, 10, 1),
(6, 11, 1);

insert into pagos(orden_id, metodos_pago_id, monto, fecha_pago)values 
(16, 2, 120, '2024-10-30 11:45:00'),
(17, 3, 85, '2024-10-30 13:55:00'),
(18, 4, 60, '2024-10-30 15:30:00'),
(19, 5, 100, '2024-10-30 16:50:00'),
(20, 6, 45, '2024-10-30 18:10:00'),
(21, 1, 80, '2024-10-30 19:20:00'),
(11, 2, 85, '2024-10-30 13:20:00'),
(12, 3, 60, '2024-10-30 15:20:00'),
(13, 4, 280, '2024-10-30 16:20:00'),
(14, 5, 120, '2024-10-30 17:20:00'),
(15, 6, 80, '2024-10-30 18:20:00');