use tienda_v;
SELECT p.nombre AS Producto, p.precio, p.stock 
FROM productos p
JOIN categorias c ON p.categoria_id = c.id
WHERE c.nombre = 'Laptops';

SELECT c.nombre AS Categoria, SUM(p.stock) AS StockTotal
FROM productos p
JOIN categorias c ON p.categoria_id = c.id
GROUP BY c.nombre;

SELECT * FROM productos WHERE nombre LIKE '%Laptop%';


SELECT nombre, stock 
FROM productos 
WHERE stock < 20;

SELECT c.nombre AS Categoria, p.nombre AS Producto, MAX(p.precio) AS Precio
FROM productos p
JOIN categorias c ON p.categoria_id = c.id
GROUP BY c.nombre;

SELECT SUM(monto) AS total_pagado FROM pagos;

SELECT c.nombre AS categoria, COUNT(p.id) AS total_productos
FROM categorias c
LEFT JOIN productos p ON c.id = p.categoria_id
GROUP BY c.nombre;

UPDATE productos SET stock = stock - 1 WHERE id = 1 AND stock > 0;