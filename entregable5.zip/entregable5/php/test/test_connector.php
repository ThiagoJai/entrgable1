<?php ini_set("display_errors", "1");?>
<?php
include_once "../connectors/connector.php";
//http://localhost/objetos/entregable5/php/test/test_connector.php

echo "-- Inicio Test Connector --<br>";
$connector = new Connector();
$sql = "select version()";
try{
    $registros = $connector->getConnector()->query($sql);
    echo "Conexion Exitosa<br>";
    foreach($registros as $row){
        echo "Se conecto a ".$row[0]."<br>";
    }
}catch(Exception $e){
    echo "Error de conexion<br>";
    echo $e."<br>";
}

echo"-- Fin Test Connector --<br><br>";
?>