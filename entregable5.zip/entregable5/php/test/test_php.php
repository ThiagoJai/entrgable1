<?php ini_set("display_errors","1");?>
<?php 
    //http://localhost/objetos/entregable5/php/test/test_php.php
    echo "Versión PHP: ".phpversion()."<br>";
    echo phpinfo().'<br>';
?>