<?php
class Connector{
    public function getConnector(){
        //PDO:mariadb://localhost:3306/tienda_v

        $driver='mysql';
        $hostname='localhost';
        $username='root';
        $password='';
        $base='tienda_v';
        return new PDO("$driver:host=$hostname;dbname=$base", $username, $password);
    }

    public function insert($tabla, $campos, $values){
        $sql="insert into $tabla ($campos) values ($values)";
        return $this->getConnector()->exec($sql);
    }

    public function delete($tabla, $filtro){
        $sql="update $tabla set activo=false where $filtro";
        return $this->getConnector()->exec($sql);
    }

    public function update($tabla, $set, $filtro){
        $sql="update $tabla set $set where $filtro";
        return $this->getConnector()->exec($sql);
    }

    public function get($tabla, $filtro){
        $sql = "select * from $tabla where $filtro and activo=true";
        return $this->getConnector()->query($sql);
    }

    public function getAll($tabla){
        return $this->get($tabla, "1=1");
    }
}
?>